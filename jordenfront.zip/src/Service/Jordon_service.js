import axios from "axios";



export class Jordon_service{


    static serverurl="http://localhost:3000";

    static getalldata(){
        const dataurl=`${this.serverurl}/Home/get`
        return axios.get(dataurl)
    }
}