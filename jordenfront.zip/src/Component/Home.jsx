import React, { useEffect, useState } from 'react';
import { Jordon_service } from '../Service/Jordon_service';

const Home = () => {

    const [data, setData] = useState({
        alldata: [
           
        ],
      });
    
      const { alldata } = data;
    
      useEffect(() => {
        getdatafromserver();
      });
    
      const getdatafromserver = () => {
        Jordon_service.getalldata()
          .then((res) => {
            setData({
              ...data,
              alldata: res.data,
            });
          })
          .catch((error) => {
            console.log(error);
          });
      };

  return (
    <>
     <div className="HOME3">
        <div className="container DATA">
          <div className="row meetstudents">Meet the students</div>
          <div className="row">
            {alldata.map((loop, index) => (
              <div className="col-3" key={index}>
                <div className="card studentdata">
                  <div className="card-header">
                    <h1>
                      <img className="image-card" src="https://paintingvalley.com/sketches/anime-face-sketch-14.jpg" alt="" />
                    </h1>
                  </div>
                  <div className="card-body CARD-DATA">
                    <h4>{loop}</h4>
                    <h4>{loop.Last_Name}</h4>
                    <h4>{loop.Mobile_N0}</h4>
                    <h4>{loop.Email_Id}</h4>
                    <h4>{loop.User_Name}</h4>
                  </div>
                </div>
              </div>
            ))}
          </div>
        </div>
      </div>
    </>
  )
}

export default Home