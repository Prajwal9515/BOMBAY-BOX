

const express = require("express");
const { pool } = require("../db-config");
const nodemailer = require('nodemailer');
// const forgotpassword = require('./forgotpassword'); // Import the forgotpassword route
// const resetpassword = require('./resetpassword'); // Import the resetpassword route

const Register = express.Router();


// Email configuration using nodemailer
const transporter = nodemailer.createTransport({
    service: 'gmail', // e.g., Gmail, Yahoo, etc.
    auth: {
        user: 'sampleacc0022@gmail.com',
        pass: 'wwap mmwd ogse zrne'
    }
});

Register.get("/", (req, res) => {
    const query = "SELECT * FROM bombay_box_accounts";
    pool.query(query, (error, result) => {
        if (error) {
            return res.status(500).send(error);
        }
        return res.status(200).send(result);
    });
});

Register.post("/create", (req, res) => {
    const { custumer_name, custumer_surname, custumer_username, custumer_password, custumer_mobile, custumer_mail } = req.body;

    // Generate a random username and password (replace with your own logic)
    const generatedUsername = generateRandomUsername(custumer_name);
    const generatedPassword = generateRandomPassword();

    // Send an email with the generated username and password
    const mailOptions = {
        from: 'sampleacc0022@gmail.com',
        to: custumer_mail,
        subject: 'Registration Successful',
        text: `Hello ${custumer_name},\n\nYour registration was successful.\n\nUsername: ${generatedUsername}\nPassword: ${generatedPassword}`
    };

    transporter.sendMail(mailOptions, (err, info) => {
        if (err) {
            console.error('Error sending email:', err);
            return res.status(500).json({ error: 'Internal server error' });
        }

        const values = [custumer_name, custumer_surname, generatedUsername, generatedPassword, custumer_mobile, custumer_mail];
        const query = "INSERT INTO bombay_box_accounts (custumer_name, custumer_surname, custumer_username, custumer_password, custumer_mobile, custumer_mail) VALUES (?, ?, ?, ?, ?, ?)";
        pool.query(query, values, (error, result) => {
            if (error) {
                console.error('Error inserting user data:', error);
                return res.status(500).json({ error: 'Internal server error' });
            }
            return res.status(201).json({ message: 'User registered successfully' });
        });
    });
});


// Function to generate a random username
function generateRandomUsername(custumer_name) {
    const randomSuffix = Math.floor(Math.random() * 10000);
    return `${custumer_name}${randomSuffix}`;
}

// Function to generate a random password
function generateRandomPassword() {
    const charset = 'abcdefghijklmnopqrstuvwxyzABCDEFGHIJKLMNOPQRSTUVWXYZ0123456789!@#$%^&*()_+-=';
    const passwordLength = 10;
    let password = '';
    for (let i = 0; i < passwordLength; i++) {
        const randomIndex = Math.floor(Math.random() * charset.length);
        password += charset.charAt(randomIndex);
    }
    return password;
}


module.exports = Register;

