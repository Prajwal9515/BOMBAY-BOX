// login.js
const express = require('express');
const login = express.Router();
const { pool } = require("../db-config");

login.post('/check', (req, res) => {
  const { custumer_username, custumer_password } = req.body;

  // Retrieve the user from the database based on the provided username
  const query = "SELECT * FROM bombay_box_accounts WHERE custumer_username = ?";
  pool.query(query, [custumer_username], (error, result) => {
    if (error) {
      return res.status(500).send('Internal server error');
    }

    if (result.length === 0) {
      return res.status(401).send('Username not found');
    }

    console.log(result)
    const user = result[0];

    // Check if the provided password matches the stored password
    if (user.custumer_password !== custumer_password) {
      return res.status(401).send('Incorrect password');
    }

    // Log the user in and proceed to the protected content
    // You can use sessions or JWT for this purpose
    // You can also send a success response back to the client
    res.status(200).send({ message: 'Login successful', user});
  });
});


module.exports = login;
