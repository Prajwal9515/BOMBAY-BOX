const express = require("express");
const { pool } = require("../db-config");

const Home = express.Router();

Home.get("/get", (req, res) => {
    const query = "SELECT * FROM  bombay_box_product";
    pool.query(query, (error, result) => {
        if (error) {
            return res.status(500).send(error);
        }
        return res.status(200).send(result);
    });
});


Home.get("/getMen", (req, res) => {
    const query = "SELECT * FROM  bombay_box_product WHERE product_person = 'MEN'";
    pool.query(query, (error, result) => {
        if (error) {
            return res.status(500).send(error);
        }
        return res.status(200).send(result);
    });
});


Home.get("/getWomen", (req, res) => {
    const query = "SELECT * FROM  bombay_box_product WHERE product_person = 'WOMEN'";
    pool.query(query, (error, result) => {
        if (error) {
            return res.status(500).send(error);
        }
        return res.status(200).send(result);
    });
});


Home.get("/getKids", (req, res) => {
    const query = "SELECT * FROM  bombay_box_product WHERE product_person = 'KIDS'";
    pool.query(query, (error, result) => {
        if (error) {
            return res.status(500).send(error);
        }
        return res.status(200).send(result);
    });
});


Home.get("/getCLOTHS", (req, res) => {
    const query = "SELECT * FROM  bombay_box_product WHERE product_category = 'CLOTHS'";
    pool.query(query, (error, result) => {
        if (error) {
            return res.status(500).send(error);
        }
        return res.status(200).send(result);
    });
});

Home.post("/createproduct", (req, res) => {
    const { product_name,  product_image,product_price, product_category,product_person } = req.body;

    const values = [product_name, product_image, product_price, product_category,product_person];
    const query = "INSERT INTO bombay_box_product (product_name, product_image, product_price,  product_category, product_person) VALUES (?, ?,?, ?, ?)";
    pool.query(query, values, (error, result) => {
        if (error) {
            console.error('Error inserting product data:', error);
            return res.status(500).json({ error: 'Internal server error' });
        }
        return res.status(201).json({ message: 'Product added successfully' });
    });
});






module.exports = Home;
