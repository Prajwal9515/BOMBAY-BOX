const mysql = require('mysql2');

const pool = mysql.createPool({
    host: "localhost",
    user: 'root',
    password: 'root',
    database: 'e_commers_app',
    waitForConnections: true,
    connectionLimit: 10,
    queueLimit: 0,
});

pool.getConnection((error, connection) => {
    if (error) {
        console.error('Database connection error:', error);
    } else {
        console.log('Connected to the database!');
        // Release the connection when you're done with it.
        connection.release();
    }
});

module.exports = { pool };
